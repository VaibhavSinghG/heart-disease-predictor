# XAI Heart Disease Prediction

This project uses SHAP and LIME to explain heart disease prediction.
